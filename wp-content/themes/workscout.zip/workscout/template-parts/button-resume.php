<div class="six columns">
	<a href="<?php echo get_permalink(get_option('resume_manager_submit_resume_form_page_id')); ?>" class="button"><?php esc_html_e("Post a Resume, It's Free!",'workscout'); ?></a>
</div>