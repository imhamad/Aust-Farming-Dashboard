<?php $layout = Kirki::get_option( 'workscout','pp_jobs_old_layout', false ); ?>
<ul class="job_listings job-list full 	<?php if(!$layout) { echo "new-layout "; } ?>">
